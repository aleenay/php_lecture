<?php 
$server = "localhost";
$username = "root";
$password = "";
$database = "db_ecommerce";
$con = mysqli_connect($server ,$username ,$password ,$database);
if($con === false){
    echo "not connected";
}


?>













